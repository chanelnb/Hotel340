package controller;

import database.Connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author sogol
 */
public class LoginController implements Initializable{

    private void signsIn(ActionEvent event){                                          
        
        if(checkFields()){
            PreparedStatement pst;
            ResultSet rs;
        // get username and password
        String username = txtuser.getText();
        String password = String.valueOf(txtpass.getPassword());
        
        //select query to check if the username and password exist in the database
        String query = "SELECT * FROM `user` WHERE username = ? AND password = ?";
        try {
            pst = Connect.getConnection().prepareStatement(query);
            pst.setString(1,username);
            pst.setString(2,password);
        
            rs = pst.executeQuery();
            if(rs.next()){
                //if login successful show a new form
                Main form = new Main();
                form.setVisible(true);
                form.pack();
                form.setLocationRelativeTo(null);
                // close the current form
                this.dispose();
            }else{
                // if login unsuccessful show error message
               JOptionPane.showMessageDialog(null, "Invalid Usernamr or Password", "Login Error", 2);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }      
    }
    private void goesToSignUp(ActionEvent event){
     
        // to go signup form
    Signup signup = new Signup();
    signup.setVisible(true);
    signup.pack();
    signup.setLocationRelativeTo(null);
    signup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //close current form
    this.dispose();
    }
    
    // check if the fields are empty
    public boolean checkFields(){
    if(txtuser.getText().equals("") || txtpass.getText().equals(""))
    {
    JOptionPane.showMessageDialog(null, "One or More Fields are Empty");
        return false;    
    }
    // Check if password and confirm password are equal
    else{
        return true;
        
    }
 
}
    
    
    
    
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
