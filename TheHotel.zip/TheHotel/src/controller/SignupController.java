package controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import database.Connect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author sogol
 */
public class SignupController implements Initializable {
    
    //Function to check if fields are empty
    public boolean checkFields(){
    if(txtfname.getText().equals("") && txtlname.getText().equals("") || txtaddress.getText().equals("") ||
            txtphone.getText().equals("") ||txtemail.getText().equals("") || 
            txtuname.getText().equals("") || txtpass1.getText().equals(""))
    {
    JOptionPane.showMessageDialog(null, "One or More Fields are Empty");
        return false;    
    }
    // Check if password and confirm password are equal
    else if(!txtpass1.getText().equals(txtpass2.getText())){
        JOptionPane.showMessageDialog(null, "Password Does Not Match");
        return false;
        
    }
    // if everything is ok
    else
    return true;
}

    // Function to check if Username already exist
    public boolean isUserExist(String User){
            boolean user_Exist = false;
            Connection con = Connect.getConnection();
            PreparedStatement pst;
            ResultSet rs;
        try {
            pst = con.prepareStatement("SELECT * FROM `user` WHERE `username` = ?");
            pst.setString(1,txtuname.getText());
            rs = pst.executeQuery();
            if(rs.next()){
            user_Exist = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user_Exist;
        
    }
    
    private void register(ActionEvent event){
            String fname = txtfname.getText();
            String lname = txtlname.getText();
            String address = txtaddress.getText();
            String phone = txtphone.getText();
            String email = txtemail.getText();
            String username = txtuname.getText();
            String password = txtpass1.getText();
            String conpassword = txtpass2.getText();
            
            if(checkFields()){
                
            Connection con = Connect.getConnection();
            PreparedStatement pst;
        try {
            pst = con.prepareStatement("INSERT INTO `user`(`fname`, `lname`, `address`, `phone`, `email`, `username`, `password`) VALUES (?,?,?,?,?,?,?)");
            pst.setString(1, fname);
            pst.setString(2, lname);
            pst.setString(3, address);
            pst.setString(4, phone);
            pst.setString(5, email);
            pst.setString(6, username);
            pst.setString(7, String.valueOf(txtpass1.getPassword()));
            if(isUserExist(txtuname.getText())){
                JOptionPane.showMessageDialog(null,"Username Already Exist");
            }
            else{
                if(pst.executeUpdate() != 0){
            JOptionPane.showMessageDialog(null,"Account Created Successfully, Please Sign In");
            // Open the Login Form
            Login log = new Login();
            log.setVisible(true);
            log.pack();
            log.setLocationRelativeTo(null);
            log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // close the current form
            this.dispose();
                }
            else{
            JOptionPane.showMessageDialog(null,"Something Wrong");
            }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
            
    }    
     
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
